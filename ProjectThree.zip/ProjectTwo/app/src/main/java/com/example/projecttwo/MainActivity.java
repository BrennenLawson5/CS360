package com.example.projecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.database.Cursor;
import android.graphics.Typeface;
import android.widget.GridLayout;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private String currentUsername;

    private EditText editUsername;
    private EditText editPassword;
    private TextView textLoginStatus;

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);

        showLoginScreen();
    }

    // Handles the user's response to the SMS permission request.
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            TextView textSmsStatus = findViewById(R.id.textSmsStatus);

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textSmsStatus.setText("SMS notifications are enabled.");
            } else {
                textSmsStatus.setText("SMS permission denied. The app will continue without SMS notifications.");
            }
        }
    }

    // Sends an SMS notification when the user reaches the saved goal weight and permission is granted.
    private void sendGoalSmsIfAllowed(double currentWeight) {
        double goalWeight = databaseHelper.getGoalWeight(currentUsername);

        if (goalWeight < 0 || currentWeight > goalWeight) {
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    "4235589441",
                    null,
                    "Congratulations! You reached your goal weight in Shed-It.",
                    null,
                    null
            );

            Toast.makeText(this, "Goal SMS notification sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception exception) {
            Toast.makeText(this, "SMS notification could not be sent.", Toast.LENGTH_SHORT).show();
        }
    }

    // Displays the login screen and connects the login and account creation buttons.
    private void showLoginScreen() {
        setContentView(R.layout.activity_login);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        textLoginStatus = findViewById(R.id.textLoginStatus);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(view -> logInUser());
        buttonCreateAccount.setOnClickListener(view -> createAccount());
    }

    // Validates account fields and saves a new user account to the database.
    private void createAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            textLoginStatus.setText("Please enter a username and password.");
            return;
        }

        boolean accountCreated = databaseHelper.createUser(username, password);

        if (accountCreated) {
            textLoginStatus.setText("Account created! You can now log in.");
        } else {
            textLoginStatus.setText("That username already exists.");
        }
    }

    // Checks login credentials and opens the dashboard when the user is valid.
    private void logInUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            textLoginStatus.setText("Please enter a username and password.");
            return;
        }

        boolean loginSuccessful = databaseHelper.checkUser(username, password);

        if (loginSuccessful) {
            currentUsername = username;
            showDashboardScreen();
        } else {
            textLoginStatus.setText("Invalid username or password.");
        }
    }

    // Displays the dashboard with the user's latest saved weight and goal weight.
    private void showDashboardScreen() {
        setContentView(R.layout.activity_dashboard);

        TextView textCurrentWeight = findViewById(R.id.textCurrentWeight);
        TextView textProgressMessage = findViewById(R.id.textProgressMessage);

        double latestWeight = databaseHelper.getLatestWeight(currentUsername);

        if (latestWeight >= 0) {
            textCurrentWeight.setText("Current Weight: " + latestWeight);
            textProgressMessage.setText("Latest weight saved successfully.");
        } else {
            textCurrentWeight.setText("Current Weight: --");
            textProgressMessage.setText("Welcome, " + currentUsername + ".");
        }

        TextView textGoalWeight = findViewById(R.id.textGoalWeight);
        double goalWeight = databaseHelper.getGoalWeight(currentUsername);

        if (goalWeight >= 0) {
            textGoalWeight.setText("Goal Weight: " + goalWeight);
        } else {
            textGoalWeight.setText("Goal Weight: --");
        }

        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);
        Button buttonViewHistory = findViewById(R.id.buttonViewHistory);
        Button buttonSmsNotifications = findViewById(R.id.buttonSmsNotifications);
        Button buttonSetGoal = findViewById(R.id.buttonSetGoal);

        buttonAddWeight.setOnClickListener(view -> showAddWeightScreen());
        buttonViewHistory.setOnClickListener(view -> showHistoryScreen());
        buttonSmsNotifications.setOnClickListener(view -> showSmsPermissionScreen());
        buttonSetGoal.setOnClickListener(view -> showGoalScreen());
    }

    // Allows the user to enter and save a new weight record.
    private void showAddWeightScreen() {
        setContentView(R.layout.activity_add_weight);

        EditText editWeight = findViewById(R.id.editWeight);
        TextView textEntryDate = findViewById(R.id.textEntryDate);
        Button buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        Button buttonCancelWeight = findViewById(R.id.buttonCancelWeight);

        String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
        textEntryDate.setText("Date: " + currentDate);

        buttonSaveWeight.setOnClickListener(view -> {
            String weightText = editWeight.getText().toString().trim();

            if (weightText.isEmpty()) {
                editWeight.setError("Enter a weight.");
                return;
            }

            double weightValue = Double.parseDouble(weightText);
            boolean saved = databaseHelper.addWeight(currentUsername, weightValue, currentDate);

            if (saved) {
                sendGoalSmsIfAllowed(weightValue);
                showDashboardScreen();
            } else {
                editWeight.setError("Weight could not be saved.");
            }
        });

        buttonCancelWeight.setOnClickListener(view -> showDashboardScreen());
    }

    private void showGoalScreen() {
        setContentView(R.layout.activity_goal);

        EditText editGoalWeight = findViewById(R.id.editGoalWeight);
        Button buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        Button buttonCancelGoal = findViewById(R.id.buttonCancelGoal);

        buttonSaveGoal.setOnClickListener(view -> {
            String goalText = editGoalWeight.getText().toString().trim();

            if (goalText.isEmpty()) {
                editGoalWeight.setError("Enter a goal weight.");
                return;
            }

            double goalWeight = Double.parseDouble(goalText);
            boolean saved = databaseHelper.saveGoalWeight(currentUsername, goalWeight);

            if (saved) {
                showDashboardScreen();
            } else {
                editGoalWeight.setError("Goal could not be saved.");
            }
        });

        buttonCancelGoal.setOnClickListener(view -> showDashboardScreen());
    }

    // Loads saved weight records from the database and displays them in the grid.
    private void showHistoryScreen() {
        setContentView(R.layout.activity_history);

        GridLayout gridWeightHistory = findViewById(R.id.gridWeightHistory);
        gridWeightHistory.removeAllViews();

        addGridCell(gridWeightHistory, "Date", true);
        addGridCell(gridWeightHistory, "Weight", true);

        Cursor cursor = databaseHelper.getWeights(currentUsername);

        if (cursor.getCount() == 0) {
            addGridCell(gridWeightHistory, "No entries yet", false);
            addGridCell(gridWeightHistory, "--", false);
        } else {
            while (cursor.moveToNext()) {
                String entryDate = cursor.getString(1);
                double weightValue = cursor.getDouble(2);

                addGridCell(gridWeightHistory, entryDate, false);
                addGridCell(gridWeightHistory, String.valueOf(weightValue), false);
            }
        }

        cursor.close();

        Button buttonAddEntry = findViewById(R.id.buttonAddEntry);
        Button buttonUpdateEntry = findViewById(R.id.buttonUpdateEntry);
        Button buttonDeleteEntry = findViewById(R.id.buttonDeleteEntry);
        Button buttonBackToDashboard = findViewById(R.id.buttonBackToDashboard);

        buttonAddEntry.setOnClickListener(view -> showAddWeightScreen());
        buttonUpdateEntry.setOnClickListener(view -> showUpdateWeightScreen());
        buttonDeleteEntry.setOnClickListener(view -> showDeleteWeightScreen());
        buttonBackToDashboard.setOnClickListener(view -> showDashboardScreen());
    }

    // Displays SMS permission options and requests permission when the user enables SMS.
    private void showSmsPermissionScreen() {
        setContentView(R.layout.activity_sms_permission);

        TextView textSmsStatus = findViewById(R.id.textSmsStatus);
        Button buttonEnableSms = findViewById(R.id.buttonEnableSms);
        Button buttonNoSms = findViewById(R.id.buttonNoSms);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textSmsStatus.setText("SMS notifications are enabled.");
        } else {
            textSmsStatus.setText("SMS notifications are optional. The app will still work without them.");
        }

        buttonEnableSms.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE
                );
            } else {
                textSmsStatus.setText("SMS notifications are already enabled.");
            }
        });

        buttonNoSms.setOnClickListener(view -> showDashboardScreen());
    }

    private void addGridCell(GridLayout gridLayout, String text, boolean isHeader) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(12, 12, 12, 12);
        textView.setTextSize(16);

        if (isHeader) {
            textView.setTypeface(null, Typeface.BOLD);
        }

        gridLayout.addView(textView);
    }

    // Lets the user update the most recent saved weight entry.
    private void showUpdateWeightScreen() {
        int latestWeightId = databaseHelper.getLatestWeightId(currentUsername);
        double latestWeight = databaseHelper.getLatestWeight(currentUsername);
        String latestDate = databaseHelper.getLatestWeightDate(currentUsername);

        if (latestWeightId == -1) {
            showHistoryScreen();
            return;
        }

        setContentView(R.layout.activity_add_weight);

        EditText editWeight = findViewById(R.id.editWeight);
        TextView textAddWeightTitle = findViewById(R.id.textAddWeightTitle);
        TextView textEntryDate = findViewById(R.id.textEntryDate);
        Button buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        Button buttonCancelWeight = findViewById(R.id.buttonCancelWeight);

        textAddWeightTitle.setText("Update Latest Weight");
        editWeight.setText(String.valueOf(latestWeight));
        textEntryDate.setText("Date: " + latestDate);
        buttonSaveWeight.setText("Update Weight");

        buttonSaveWeight.setOnClickListener(view -> {
            String weightText = editWeight.getText().toString().trim();

            if (weightText.isEmpty()) {
                editWeight.setError("Enter a weight.");
                return;
            }

            double updatedWeight = Double.parseDouble(weightText);
            boolean updated = databaseHelper.updateWeight(latestWeightId, updatedWeight, latestDate);

            if (updated) {
                showHistoryScreen();
            } else {
                editWeight.setError("Weight could not be updated.");
            }
        });

        buttonCancelWeight.setOnClickListener(view -> showHistoryScreen());
    }

    // Deletes the most recent saved weight entry and refreshes the history grid.
    private void showDeleteWeightScreen() {
        int latestWeightId = databaseHelper.getLatestWeightId(currentUsername);

        if (latestWeightId != -1) {
            databaseHelper.deleteWeight(latestWeightId);
        }

        showHistoryScreen();
    }
}