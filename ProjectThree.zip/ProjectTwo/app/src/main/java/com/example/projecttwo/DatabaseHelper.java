package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ShedIt.db";
    private static final int DATABASE_VERSION = 2;
    public static final String TABLE_GOALS = "goals";
    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHTS = "weights";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates the database tables used for user accounts, saved weights, and goal weights.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)";

        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                "weight_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL, " +
                "weight_value REAL NOT NULL, " +
                "entry_date TEXT NOT NULL)";

        String createGoalsTable = "CREATE TABLE " + TABLE_GOALS + " (" +
                "goal_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "goal_weight REAL NOT NULL)";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
        db.execSQL(createGoalsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        onCreate(db);
    }

    // Adds a new username and password record for account creation.
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Checks whether the entered username and password match a saved account.
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE username = ? AND password = ?",
                new String[]{username, password}
        );

        boolean userExists = cursor.getCount() > 0;
        cursor.close();

        return userExists;
    }

    // Saves a new weight entry for the logged-in user.
    public boolean addWeight(String username, double weightValue, String entryDate) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("weight_value", weightValue);
        values.put("entry_date", entryDate);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    // Retrieves all saved weight entries for the logged-in user.
    public Cursor getWeights(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT weight_id, entry_date, weight_value FROM " + TABLE_WEIGHTS +
                        " WHERE username = ? ORDER BY weight_id DESC",
                new String[]{username}
        );
    }

    public boolean updateWeight(int weightId, double weightValue, String entryDate) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("weight_value", weightValue);
        values.put("entry_date", entryDate);

        int rowsUpdated = db.update(
                TABLE_WEIGHTS,
                values,
                "weight_id = ?",
                new String[]{String.valueOf(weightId)}
        );

        return rowsUpdated > 0;
    }

    public boolean deleteWeight(int weightId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_WEIGHTS,
                "weight_id = ?",
                new String[]{String.valueOf(weightId)}
        );

        return rowsDeleted > 0;
    }
    public double getLatestWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT weight_value FROM " + TABLE_WEIGHTS +
                        " WHERE username = ? ORDER BY weight_id DESC LIMIT 1",
                new String[]{username}
        );

        double latestWeight = -1;

        if (cursor.moveToFirst()) {
            latestWeight = cursor.getDouble(0);
        }

        cursor.close();

        return latestWeight;
    }

    // Saves a new goal weight or updates the existing goal for the user.
    public boolean saveGoalWeight(String username, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("goal_weight", goalWeight);

        int rowsUpdated = db.update(
                TABLE_GOALS,
                values,
                "username = ?",
                new String[]{username}
        );

        if (rowsUpdated > 0) {
            return true;
        }

        long result = db.insert(TABLE_GOALS, null, values);
        return result != -1;
    }

    public double getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT goal_weight FROM " + TABLE_GOALS + " WHERE username = ?",
                new String[]{username}
        );

        double goalWeight = -1;

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
        }

        cursor.close();

        return goalWeight;
    }

    public int getLatestWeightId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT weight_id FROM " + TABLE_WEIGHTS +
                        " WHERE username = ? ORDER BY weight_id DESC LIMIT 1",
                new String[]{username}
        );

        int weightId = -1;

        if (cursor.moveToFirst()) {
            weightId = cursor.getInt(0);
        }

        cursor.close();

        return weightId;
    }

    public String getLatestWeightDate(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT entry_date FROM " + TABLE_WEIGHTS +
                        " WHERE username = ? ORDER BY weight_id DESC LIMIT 1",
                new String[]{username}
        );

        String entryDate = "";

        if (cursor.moveToFirst()) {
            entryDate = cursor.getString(0);
        }

        cursor.close();

        return entryDate;
    }
}